from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from .models import FaceData, FaceLogData
import json
import face_recognition
from django.db import transaction

@csrf_exempt
def process_application(request):
    if request.method == 'POST':
        try:
            data = json.loads(request.body)
            image_data = data.get('image')
            app_type = data.get('application_type')
            
            if not image_data or not app_type:
                return JsonResponse({
                    'success': False,
                    'message': "Ma'lumotlar to'liq emas"
                })
            
            with transaction.atomic():
                # Yangi yuzni yaratish
                try:
                    new_face = FaceData.create_from_image(image_data)
                except ValueError as e:
                    return JsonResponse({
                        'success': False,
                        'message': str(e)
                    })
                
                # Bazadagi yuzlar bilan solishtirish
                existing_faces = FaceData.objects.exclude(id=new_face.id)
                for face in existing_faces:
                    matches = face_recognition.compare_faces(
                        [face.encoding],
                        new_face.encoding,
                        tolerance=0.6
                    )
                    
                    if matches[0]:
                        # Kunlik kirishlar sonini tekshirish
                        entries_today = FaceLogData.get_today_entries(face.id)
                        if entries_today >= 3:
                            return JsonResponse({
                                'success': False,
                                'message': "Ogohlantirish: Kunlik chegaradan o'tib ketdingiz (3 marta)",
                                'limit_reached': True
                            })
                        
                        # Log yozuvini yaratish
                        FaceLogData.objects.create(
                            face_id=face.id,
                            application_type=app_type
                        )
                        
                        return JsonResponse({
                            'success': True,
                            'message': "Ariza qabul qilindi",
                            'face_id': face.id
                        })
                
                # Yangi yuz uchun log yozuvi
                FaceLogData.objects.create(
                    face=new_face,
                    application_type=app_type
                )
                
                return JsonResponse({
                    'success': True,
                    'message': "Yangi yuz qo'shildi va ariza qabul qilindi",
                    'face_id': new_face.id
                })
                
        except Exception as e:
            return JsonResponse({
                'success': False,
                'message': f"Xato: {str(e)}"
            })
    
    return JsonResponse({
        'success': False,
        'message': "Noto'g'ri so'rov"
    })