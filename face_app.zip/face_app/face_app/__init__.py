# Bu fayl bo'sh qolishi mumkin yoki quyidagicha yozilishi mumkin
from .celery import app as celery_app

__all__ = ('celery_app',)