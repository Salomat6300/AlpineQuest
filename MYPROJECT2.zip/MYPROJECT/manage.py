import tkinter as tk
from tkinter import ttk, messagebox, font
from PIL import Image, ImageTk
import cv2
import numpy as np
from datetime import datetime
import time
from database import FaceDB
from face_recognizer import YuzTanibOlovchi
import face_recognition

class FaceRecognitionApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Yuzni Tanib Olish Dasturi")
        self.root.geometry("1000x700")
        self.root.configure(bg='#f0f0f0')
        
        # Initialize database
        self.face_db = FaceDB("face_db", "postgres", "123", "localhost", "5432")
        if not self.face_db.jadvallarni_yaratish():
            messagebox.showerror("Xatolik", "Bazaga ulanib bo'lmadi!")
            self.root.destroy()
            return
        
        # Initialize face recognizer
        self.face_recognizer = None
        self.is_camera_running = False
        self.current_frame = None
        self.last_log_times = {}
        self.frame_count = 0
        self.last_face_data = None
        
        # Create UI
        self.create_ui()
    
    def create_ui(self):
        """Create user interface"""
        # Custom fonts
        self.title_font = font.Font(family='Helvetica', size=16, weight='bold')
        self.button_font = font.Font(family='Helvetica', size=12)
        self.label_font = font.Font(family='Helvetica', size=11)
        
        # Main container
        self.main_frame = tk.Frame(self.root, bg='#f0f0f0')
        self.main_frame.pack(expand=True, fill='both', padx=20, pady=20)
        
        # Title label
        self.title_label = tk.Label(
            self.main_frame, 
            text="Yuzni Tanib Olish Dasturi",
            font=self.title_font,
            bg='#f0f0f0'
        )
        self.title_label.pack(pady=(0, 20))
        
        # Camera frame
        self.camera_frame = tk.Label(self.main_frame, bg='black')
        self.camera_frame.pack(pady=10)
        
        # Status label
        self.status_label = tk.Label(
            self.main_frame, 
            text="Dastur tayyor. Kamerani yoqish uchun tugmani bosing.",
            font=self.button_font,
            bg='#f0f0f0'
        )
        self.status_label.pack(pady=10)
        
        # Button frame
        self.button_frame = tk.Frame(self.main_frame, bg='#f0f0f0')
        self.button_frame.pack(pady=20)
        
        # Start button
        self.start_btn = tk.Button(
            self.button_frame, 
            text="Kamerani Yoqish", 
            command=self.start_camera,
            font=self.button_font,
            width=15,
            height=2,
            bg='#4CAF50',
            fg='white'
        )
        self.start_btn.pack(side=tk.LEFT, padx=10)
        
        # Stop button
        self.stop_btn = tk.Button(
            self.button_frame, 
            text="Kamerani O'chirish", 
            command=self.stop_camera,
            font=self.button_font,
            width=15,
            height=2,
            bg='#f44336',
            fg='white',
            state=tk.DISABLED
        )
        self.stop_btn.pack(side=tk.LEFT, padx=10)
        
        # Users button
        self.users_btn = tk.Button(
            self.button_frame, 
            text="Foydalanuvchilar", 
            command=self.show_users,
            font=self.button_font,
            width=15,
            height=2,
            bg='#2196F3',
            fg='white'
        )
        self.users_btn.pack(side=tk.LEFT, padx=10)
    
    def start_camera(self):
        """Start the face recognition camera"""
        if not self.is_camera_running:
            self.face_recognizer = YuzTanibOlovchi(self.face_db)
            if self.face_recognizer.ishga_tushirish():
                # Set camera properties for better performance
                self.face_recognizer.video_kamera.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
                self.face_recognizer.video_kamera.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)
                self.face_recognizer.video_kamera.set(cv2.CAP_PROP_FPS, 30)
                
                self.is_camera_running = True
                self.start_btn.config(state=tk.DISABLED)
                self.stop_btn.config(state=tk.NORMAL)
                self.status_label.config(text="Kamera ishlamoqda. Yuzlami tanib olish jarayoni...")
                
                # Start camera update loop
                self.update_camera()
            else:
                messagebox.showerror("Xatolik", "Kamerani yoqib bo'lmadi!")
    
    def stop_camera(self):
        """Stop the face recognition camera"""
        if self.is_camera_running:
            self.is_camera_running = False
            self.start_btn.config(state=tk.NORMAL)
            self.stop_btn.config(state=tk.DISABLED)
            self.status_label.config(text="Kamera o'chirilgan")
            
            if self.face_recognizer:
                self.face_recognizer.tozalash()
                self.face_recognizer = None
    
    def update_camera(self):
        """Update the camera frame in the GUI"""
        if not self.is_camera_running or not hasattr(self, 'face_recognizer'):
            return
            
        start_time = time.time()
        
        # Read frame from camera
        ret, frame = self.face_recognizer.video_kamera.read()
        if not ret:
            self.root.after(10, self.update_camera)
            return
        
        # Mirror the frame
        frame = cv2.flip(frame, 1)
        display_frame = cv2.resize(frame, (640, 480))
        
        # Process every 3rd frame for face recognition to improve performance
        if self.frame_count % 3 == 0:
            small_frame = cv2.resize(frame, (0, 0), fx=0.5, fy=0.5)
            rgb_frame = cv2.cvtColor(small_frame, cv2.COLOR_BGR2RGB)
            
            # Face detection
            face_locations = face_recognition.face_locations(
                rgb_frame, 
                model="hog"  # Use faster HOG method instead of CNN
            )
            
            # Scale back face locations to original frame size
            face_locations = [(top*2, right*2, bottom*2, left*2) for (top, right, bottom, left) in face_locations]
            
            names = []
            if face_locations:
                # Get main face
                main_face = self.get_main_face(face_locations, frame.shape)
                
                if main_face:
                    top, right, bottom, left = main_face
                    
                    # Face recognition
                    face_encodings = face_recognition.face_encodings(
                        rgb_frame, 
                        known_face_locations=[(top//2, right//2, bottom//2, left//2)],
                        num_jitters=1
                    )
                    
                    if face_encodings:
                        face_encoding = face_encodings[0]
                        sub_frame = frame[top:bottom, left:right]
                        orientation = self.face_recognizer.orient_detector.detect(sub_frame)
                        
                        if orientation:
                            if len(self.face_recognizer.malum_yuz_kodlari) > 0:
                                face_distances = face_recognition.face_distance(
                                    self.face_recognizer.malum_yuz_kodlari, 
                                    face_encoding
                                )
                                best_match_index = np.argmin(face_distances)
                                
                                if face_distances[best_match_index] < 0.5:
                                    face_id = self.face_recognizer.malum_yuz_ids[best_match_index]
                                    name = f"ID-{face_id}"
                                    
                                    current_time = datetime.now()
                                    need_log = False
                                    
                                    if face_id not in self.last_log_times:
                                        need_log = True
                                    else:
                                        time_diff = (current_time - self.last_log_times[face_id]).total_seconds()
                                        if time_diff >= 30:
                                            need_log = True
                                    
                                    if need_log:
                                        self.face_db.kirishni_loglash(face_id)
                                        self.last_log_times[face_id] = current_time
                                else:
                                    name = "Nomalum shaxs!"
                                    face_id = None
                            else:
                                name = "Nomalum shaxs!"
                                face_id = None
                            
                            if name == "Nomalum shaxs!":
                                face_image = frame[top:bottom, left:right]
                                face_id = self.face_db.yuz_qoshish(face_image, face_encoding)
                                if face_id:
                                    name = f"ID-{face_id}"
                                    self.face_recognizer.malum_yuz_ids.append(face_id)
                                    self.face_recognizer.malum_yuz_kodlari = np.vstack([self.face_recognizer.malum_yuz_kodlari, face_encoding]) if len(self.face_recognizer.malum_yuz_kodlari) > 0 else np.array([face_encoding])
                                    self.last_log_times[face_id] = current_time
                        else:
                            name = "Yuz holati noto'g'ri"
                        
                        names.append(name)
            
            # Save face data for drawing between detections
            self.last_face_data = {
                'locations': face_locations,
                'names': names,
                'timestamp': time.time()
            }
        
        self.frame_count += 1
        
        # Draw faces from last detection
        if self.last_face_data and (time.time() - self.last_face_data['timestamp'] < 0.5):  # 0.5 sec oldingi ma'lumot
            for (top, right, bottom, left), name in zip(self.last_face_data['locations'], self.last_face_data['names']):
                cv2.rectangle(display_frame, (left, top), (right, bottom), (0, 255, 0), 2)
                cv2.putText(
                    display_frame, name, (left + 6, bottom - 6), 
                    cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 1
                )
        
        # Convert frame to PhotoImage
        img = Image.fromarray(cv2.cvtColor(display_frame, cv2.COLOR_BGR2RGB))
        imgtk = ImageTk.PhotoImage(image=img)
        
        # Update the label
        self.camera_frame.imgtk = imgtk
        self.camera_frame.config(image=imgtk)
        
        # Calculate processing time and adjust delay
        processing_time = time.time() - start_time
        delay = max(1, int(33 - (processing_time * 1000)))  # Target ~30 FPS
        
        # Schedule next update
        self.root.after(delay, self.update_camera)
    
    def get_main_face(self, face_locations, frame_shape):
        """Get the main face closest to the center"""
        if not face_locations:
            return None
            
        height, width = frame_shape[:2]  # frame_shape parametridan foydalanish
        center_x, center_y = width // 2, height // 2
        
        min_distance = float('inf')
        main_face = None
        
        for (top, right, bottom, left) in face_locations:
            face_center_x = (left + right) // 2
            face_center_y = (top + bottom) // 2
            
            distance = np.sqrt((face_center_x - center_x)**2 + (face_center_y - center_y)**2)
            
            if distance < min_distance:
                min_distance = distance
                main_face = (top, right, bottom, left)
        
        return main_face
    
    def show_users(self):
        """Show users window"""
        # Foydalanuvchilar oynasini ko'rsatish kodi...
        pass
    
    def on_closing(self):
        """Handle window closing event"""
        self.stop_camera()
        self.root.destroy()

if __name__ == "__main__":
    root = tk.Tk()
    app = FaceRecognitionApp(root)
    root.protocol("WM_DELETE_WINDOW", app.on_closing)
    root.mainloop()