import cv2
import numpy as np
from datetime import datetime
import torch
from facenet_pytorch import InceptionResnetV1
from torchvision import transforms
from PIL import Image
from MYPROJECT.face_orientation import FaceOrientationDetector
import mediapipe as mp

class YuzTanibOlovchi:
    def __init__(self, face_db):
        self.face_db = face_db
        self.video_kamera = None
        self.malum_yuz_ids = []
        self.malum_yuz_kodlari = []
        self.orient_detector = FaceOrientationDetector()
        
        # GPU uchun model
        self.device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
        self.resnet = InceptionResnetV1(pretrained='vggface2').eval().to(self.device)
        self.transform = transforms.Compose([
            transforms.Resize(160),
            transforms.ToTensor(),
            transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])
        ])
        
        # MediaPipe yuzni aniqlash modeli
        self.mp_face_detection = mp.solutions.face_detection
        self.face_detection = self.mp_face_detection.FaceDetection(
            model_selection=1,  # 1 - yuqori aniqlik modeli
            min_detection_confidence=0.7
        )

    def ishga_tushirish(self):
        self.malum_yuz_ids, self.malum_yuz_kodlari = self.face_db.barcha_yuzlarni_olish()
        self.video_kamera = cv2.VideoCapture(0)
        if not self.video_kamera.isOpened():
            print("Kamerani ochib bo'lmadi!")
            return False
        return True

    def get_main_face(self, face_locations, frame_shape):
        """Diqqat markazidagi asosiy yuzni aniqlaydi"""
        if not face_locations:
            return None
            
        height, width = frame_shape[:2]
        center_x, center_y = width // 2, height // 2
        
        # Eng yaqin yuzni topish (markazga eng yaqin)
        min_distance = float('inf')
        main_face = None
        
        for face_loc in face_locations:
            # MediaPipe formatidan OpenCV formatiga o'tkazish
            relative_bounding_box = face_loc.location_data.relative_bounding_box
            x = int(relative_bounding_box.xmin * width)
            y = int(relative_bounding_box.ymin * height)
            w = int(relative_bounding_box.width * width)
            h = int(relative_bounding_box.height * height)
            
            # Yuz joylashuvini kadr chegaralarida tekshirish
            x = max(0, x)
            y = max(0, y)
            w = min(width - x, w)
            h = min(height - y, h)
            
            if w <= 0 or h <= 0:  # Noto'g'ri o'lchamlar
                continue
                
            face_center_x = x + w // 2
            face_center_y = y + h // 2
            
            distance = np.sqrt((face_center_x - center_x)**2 + (face_center_y - center_y)**2)
            
            if distance < min_distance:
                min_distance = distance
                main_face = (y, x + w, y + h, x)  # (top, right, bottom, left)
        
        return main_face

    def yuzdan_kod_olish(self, yuz_rasmi):
        """Yuz rasmidan 128 o'lchovli vektor olish"""
        try:
            yuz_pil = Image.fromarray(cv2.cvtColor(yuz_rasmi, cv2.COLOR_BGR2RGB))
            yuz_tensor = self.transform(yuz_pil).unsqueeze(0).to(self.device)
            
            with torch.no_grad():
                embedding = self.resnet(yuz_tensor)
            
            return embedding.cpu().numpy().flatten()
        except Exception as e:
            print(f"Yuz kodini olishda xatolik: {e}")
            return None

    def yuzlarni_tanib_olish(self):
        oxirgi_log_vaqtlari = {}
        while True:
            joriy_vaqt = datetime.now()
            muvaffaqiyatli, kadr = self.video_kamera.read()
            if not muvaffaqiyatli:
                print("Kadrni o'qib bo'lmadi!")
                break
                
            kadr = cv2.flip(kadr, 1)
            height, width = kadr.shape[:2]

            # MediaPipe yordamida yuzlarni aniqlash
            rgb_kadr = cv2.cvtColor(kadr, cv2.COLOR_BGR2RGB)
            results = self.face_detection.process(rgb_kadr)
            
            # Faqat diqqat markazidagi asosiy yuzni olish
            main_face = None
            if results.detections:
                main_face = self.get_main_face(results.detections, kadr.shape)
            
            if not main_face:
                cv2.imshow("Yuzni tanib olish", kadr)
                if cv2.waitKey(1) & 0xFF == ord('q'):
                    break
                continue
            
            yuqori, ong, past, chap = main_face
            # Yuzni kadrdan kesib olish va to'g'riligini tekshirish
            yuqori, past = max(0, yuqori), min(height, past)
            chap, ong = max(0, chap), min(width, ong)
            
            if past <= yuqori or ong <= chap:  # Noto'g'ri kesish
                cv2.imshow("Yuzni tanib olish", kadr)
                if cv2.waitKey(1) & 0xFF == ord('q'):
                    break
                continue
                
            yuz_rasmi = kadr[yuqori:past, chap:ong]
            if yuz_rasmi.size == 0:  # Bo'sh rasm
                cv2.imshow("Yuzni tanib olish", kadr)
                if cv2.waitKey(1) & 0xFF == ord('q'):
                    break
                continue

            # Yuz holatini tekshirish
            try:
                orientation = self.orient_detector.detect(yuz_rasmi)
            except Exception as e:
                print(f"Yuz holatini aniqlashda xatolik: {e}")
                orientation = 0
                
            if not orientation:
                ism = "Yuz holati noto'g'ri"
            else:
                # Yuz kodini olish
                yuz_kodi = self.yuzdan_kod_olish(yuz_rasmi)
                if yuz_kodi is None:
                    cv2.imshow("Yuzni tanib olish", kadr)
                    if cv2.waitKey(1) & 0xFF == ord('q'):
                        break
                    continue
                
                # Ma'lum yuzlar bilan solishtirish
                ism = "Noma'lum shaxs!"
                yuz_id = None
                
                if len(self.malum_yuz_kodlari) > 0:
                    # Euclidean masofani hisoblash
                    kodlar = np.array(self.malum_yuz_kodlari)
                    masofalar = np.linalg.norm(kodlar - yuz_kodi, axis=1)
                    eng_yakin_idx = np.argmin(masofalar)
                    
                    if masofalar[eng_yakin_idx] < 0.8:  # Chegara
                        yuz_id = self.malum_yuz_ids[eng_yakin_idx]
                        ism = f"ID-{yuz_id}"
                        
                        # 30 sekunddan keyin log yozish
                        log_kerak = False
                        if yuz_id not in oxirgi_log_vaqtlari:
                            log_kerak = True
                        else:
                            vaqt_farqi = (joriy_vaqt - oxirgi_log_vaqtlari[yuz_id]).total_seconds()
                            if vaqt_farqi >= 30:
                                log_kerak = True
                        
                        if log_kerak:
                            self.face_db.kirishni_loglash(yuz_id)
                            oxirgi_log_vaqtlari[yuz_id] = joriy_vaqt
                
                if yuz_id is None:
                    # Yangi yuzni bazaga qo'shish
                    yuz_id = self.face_db.yuz_qoshish(yuz_rasmi, yuz_kodi)
                    if yuz_id:
                        ism = f"ID-{yuz_id}"
                        self.malum_yuz_ids.append(yuz_id)
                        self.malum_yuz_kodlari.append(yuz_kodi)
                        oxirgi_log_vaqtlari[yuz_id] = joriy_vaqt

            # Natijalarni ekranga chiqarish
            cv2.rectangle(kadr, (chap, yuqori), (ong, past), (0, 255, 0), 2)
            cv2.putText(
                kadr, ism, (chap + 6, past - 6), 
                cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 1
            )

            cv2.imshow("Yuzni tanib olish", kadr)

            if cv2.waitKey(1) & 0xFF == ord('q'):
                break

    def tozalash(self):
        if self.video_kamera:
            self.video_kamera.release()
        cv2.destroyAllWindows()
        self.face_detection.close()