import cv2
import face_recognition
import numpy as np
from datetime import datetime
from face_orientation import FaceOrientationDetector

class YuzTanibOlovchi:
    def __init__(self, face_db):
        self.face_db = face_db
        self.video_kamera = None
        self.malum_yuz_ids = []
        self.malum_yuz_kodlari = []
        self.orient_detector = FaceOrientationDetector()
        self.oxirgi_log_vaqtlari = {}
        
        # GPU tezlashtirishni tekshirish
        self.face_recognition_gpu_enabled = False
        try:
            import dlib
            if dlib.DLIB_USE_CUDA:
                self.face_recognition_gpu_enabled = True
                print("GPU tezlashtirish yoqilgan")
            else:
                print("Diqqat: GPU tezlashtirish mavjud emas")
        except:
            print("Diqqat: GPU holatini tekshirib bo'lmadi")

    def ishga_tushirish(self):
        """Dasturni ishga tushirish"""
        self.malum_yuz_ids, self.malum_yuz_kodlari = self.face_db.barcha_yuzlarni_olish()
        
        # Kamera parametrlari
        self.video_kamera = cv2.VideoCapture(0)
        self.video_kamera.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
        self.video_kamera.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)
        self.video_kamera.set(cv2.CAP_PROP_FPS, 30)
        
        if not self.video_kamera.isOpened():
            print("Kamerani ochib bo'lmadi!")
            return False
        
        # Ma'lum yuz kodlarini numpy arrayga o'tkazish
        if self.malum_yuz_kodlari:
            self.malum_yuz_kodlari = np.array(self.malum_yuz_kodlari)
        
        return True

    def get_main_face(self, face_locations, frame_shape):
        """Diqqat markazidagi asosiy yuzni aniqlash"""
        if not face_locations:
            return None
            
        height, width = frame_shape[:2]
        center_x, center_y = width // 2, height // 2
        
        # Eng yaqin yuzni topish (markazga eng yaqin)
        min_distance = float('inf')
        main_face = None
        
        for (top, right, bottom, left) in face_locations:
            face_center_x = (left + right) // 2
            face_center_y = (top + bottom) // 2
            
            distance = np.sqrt((face_center_x - center_x)**2 + (face_center_y - center_y)**2)
            
            if distance < min_distance:
                min_distance = distance
                main_face = (top, right, bottom, left)
        
        return main_face

    def yuzlarni_tanib_olish(self, frame):
        """Kadrdagi yuzlarni aniqlash va qayta ishlash"""
        # Kadrni kichraytirish tezlik uchun
        small_frame = cv2.resize(frame, (0, 0), fx=0.5, fy=0.5)
        rgb_small_frame = cv2.cvtColor(small_frame, cv2.COLOR_BGR2RGB)
        
        # Yuz joylarini aniqlash
        yuz_joylari = face_recognition.face_locations(
            rgb_small_frame, 
            model="cnn" if self.face_recognition_gpu_enabled else "hog"
        )
        
        # Asosiy yuzni aniqlash
        main_face = self.get_main_face(yuz_joylari, frame.shape)
        
        if main_face:
            top, right, bottom, left = main_face
            
            # Yuz kodini olish
            yuz_kodlari = face_recognition.face_encodings(
                rgb_small_frame, 
                [(top//2, right//2, bottom//2, left//2)],
                num_jitters=1
            )
            
            if yuz_kodlari:
                yuz_kodi = yuz_kodlari[0]
                joriy_vaqt = datetime.now()
                
                # Yuz holatini tekshirish
                sub_frame = frame[top:bottom, left:right]
                orientation = self.orient_detector.detect(sub_frame)
                
                if orientation:
                    # Ma'lum yuzlar bilan solishtirish
                    if len(self.malum_yuz_kodlari) > 0:
                        yuzlar_orasidagi_masofalar = face_recognition.face_distance(
                            self.malum_yuz_kodlari, 
                            yuz_kodi
                        )
                        eng_yaqin_indeks = np.argmin(yuzlar_orasidagi_masofalar)
                        
                        if yuzlar_orasidagi_masofalar[eng_yaqin_indeks] < 0.5:
                            yuz_id = self.malum_yuz_ids[eng_yaqin_indeks]
                            ism = f"ID-{yuz_id}"

                            # 30 soniyada bir marta log yozish
                            if yuz_id not in self.oxirgi_log_vaqtlari or \
                               (joriy_vaqt - self.oxirgi_log_vaqtlari[yuz_id]).total_seconds() >= 30:
                                self.face_db.kirishni_loglash(yuz_id)
                                self.oxirgi_log_vaqtlari[yuz_id] = joriy_vaqt
                        else:
                            ism = "Nomalum shaxs!"
                            yuz_id = None
                    else:
                        ism = "Nomalum shaxs!"
                        yuz_id = None

                    # Agar yuz nomalum bo'lsa, bazaga qo'shish
                    if ism == "Nomalum shaxs!":
                        yuz_rasmi = frame[top:bottom, left:right]
                        yuz_id = self.face_db.yuz_qoshish(yuz_rasmi, yuz_kodi)
                        if yuz_id:
                            ism = f"ID-{yuz_id}"
                            self.malum_yuz_ids.append(yuz_id)
                            if len(self.malum_yuz_kodlari) > 0:
                                self.malum_yuz_kodlari = np.vstack([self.malum_yuz_kodlari, yuz_kodi])
                            else:
                                self.malum_yuz_kodlari = np.array([yuz_kodi])
                            self.oxirgi_log_vaqtlari[yuz_id] = joriy_vaqt
                else:
                    ism = "Yuz holati noto'g'ri"
                
                # Yuzga to'rtburchak va ID ni chizish
                cv2.rectangle(frame, (left, top), (right, bottom), (0, 255, 0) if orientation else (0, 0, 255), 2)
                cv2.putText(
                    frame, ism, (left + 6, bottom - 6), 
                    cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0) if orientation else (0, 0, 255), 1
                )
        
        return frame

    def tozalash(self):
        """Resurslarni tozalash"""
        if self.video_kamera:
            self.video_kamera.release()
        cv2.destroyAllWindows()