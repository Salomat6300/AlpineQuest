# Bu fayl bo'sh qolishi mumkin
# Yoki quyidagicha yozishingiz mumkin:
default_app_config = 'recognition.apps.RecognitionConfig'