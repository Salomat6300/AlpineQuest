from django.urls import path
from .views import process_application
from django.views.decorators.csrf import csrf_exempt

urlpatterns = [
    path('api/process-application/', csrf_exempt(process_application))
]