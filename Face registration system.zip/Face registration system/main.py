from database import FaceDB
from interface import FaceRecognitionApp
import tkinter as tk
from ttkbootstrap import Style

if __name__ == "__main__":
    # Ma'lumotlar bazasi parametrlari
    DB_NAME = "face_db"
    DB_USER = "postgres"
    DB_PASSWORD = "123"
    DB_HOST = "localhost"
    DB_PORT = "5432"

    # Bazaga ulanish
    face_db = FaceDB(DB_NAME, DB_USER, DB_PASSWORD, DB_HOST, DB_PORT)

    # Jadvallarni yaratish
    if face_db.jadvallarni_yaratish():
        # Interfeysni ishga tushirish
        root = tk.Tk()
        style = Style(theme='darkly')  # Qorong'i mavzu
        app = FaceRecognitionApp(root, face_db)
        root.mainloop()
    else:
        print("Jadvallar yaratilmadi. Dastur toxtatildi.")