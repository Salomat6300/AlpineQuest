document.addEventListener('DOMContentLoaded', function() {
    const loading = document.getElementById('loading');
    const result = document.getElementById('result');
    const appTypeButtons = document.querySelectorAll('.app-type');
    
    loading.style.display = 'none';
    
    appTypeButtons.forEach(button => {
        button.addEventListener('click', async function() {
            const appType = this.dataset.type;
            
            try {
                // Yuklanish animatsiyasini ko'rsatish
                loading.style.display = 'block';
                result.textContent = '';
                
                // Kamerani ochish va rasm olish
                const imageData = await captureFaceImage();
                
                // Backendga yuborish
                const response = await fetch('/api/process-application/', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({
                        image: imageData,
                        application_type: appType
                    }),
                });
                
                const data = await response.json();
                
                if (data.success) {
                    result.textContent = data.message;
                    result.className = 'result success';
                } else {
                    result.textContent = data.message;
                    result.className = 'result error';
                }
            } catch (error) {
                result.textContent = 'Xatolik yuz berdi: ' + error.message;
                result.className = 'result error';
            } finally {
                loading.style.display = 'none';
            }
        });
    });
    
    async function captureFaceImage() {
        return new Promise((resolve, reject) => {
            const video = document.createElement('video');
            video.style.display = 'none';
            
            navigator.mediaDevices.getUserMedia({ video: true })
                .then(stream => {
                    video.srcObject = stream;
                    video.play();
                    
                    setTimeout(() => {
                        const canvas = document.createElement('canvas');
                        canvas.width = video.videoWidth;
                        canvas.height = video.videoHeight;
                        canvas.getContext('2d').drawImage(video, 0, 0);
                        
                        const imageData = canvas.toDataURL('image/jpeg');
                        
                        // Kamerani yopish
                        stream.getTracks().forEach(track => track.stop());
                        resolve(imageData);
                    }, 2000);
                })
                .catch(error => {
                    reject(new Error("Kameraga ulanishda xato: " + error.message));
                });
        });
    }
});