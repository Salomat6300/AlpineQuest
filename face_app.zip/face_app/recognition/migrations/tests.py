from django.test import TestCase
from .models import FaceData, FaceLogData
from django.core.files.base import ContentFile
import face_recognition
import numpy as np
from datetime import datetime, timedelta

class FaceDataModelTest(TestCase):
    def setUp(self):
        # Test uchun namuna rasm yaratish
        image = face_recognition.load_image_file("test_image.jpg")
        encoding = face_recognition.face_encodings(image)[0]
        
        self.face_data = FaceData.objects.create(
            image=b'test_image_bytes',
            encoding=encoding.tolist()
        )
    
    def test_face_creation(self):
        self.assertEqual(FaceData.objects.count(), 1)
        
class FaceLogDataModelTest(TestCase):
    def setUp(self):
        image = face_recognition.load_image_file("test_image.jpg")
        encoding = face_recognition.face_encodings(image)[0]
        
        self.face_data = FaceData.objects.create(
            image=b'test_image_bytes',
            encoding=encoding.tolist()
        )
        
        self.face_log = FaceLogData.objects.create(
            face=self.face_data,
            application_type="Test"
        )
    
    def test_log_creation(self):
        self.assertEqual(FaceLogData.objects.count(), 1)
        self.assertEqual(self.face_log.face, self.face_data)