import tkinter as tk
from tkinter import ttk, filedialog, messagebox
from PIL import Image, ImageTk
import cv2
import numpy as np
from facedb import FaceDB


class UsersWindow(tk.Tk):
    def __init__(self, face_db):
        super().__init__()
        self.face_db = face_db
        self.title("Foydalanuvchilar")
        self.geometry("900x500")

        # Chap qism (jadval)
        self.tree = ttk.Treeview(self, columns=("ID", "Yaratilgan vaqt", "Oxirgi kirish"), show="headings")
        self.tree.heading("ID", text="ID")
        self.tree.heading("Yaratilgan vaqt", text="Yaratilgan vaqt")
        self.tree.heading("Oxirgi kirish", text="Oxirgi kirish")
        self.tree.bind("<<TreeviewSelect>>", self.show_user_details)

        vsb = ttk.Scrollbar(self, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=vsb.set)

        # O'ng qism (rasm va info)
        right_frame = tk.Frame(self)
        self.image_label = tk.Label(right_frame)
        self.image_label.pack(pady=10)

        self.info_label = tk.Label(right_frame, justify="left", anchor="w", font=("Arial", 12))
        self.info_label.pack(pady=10, fill="x")

        # Pastki tugmalar
        btn_frame = tk.Frame(right_frame)
        self.btn_add = tk.Button(btn_frame, text="Yangi qo'shish", command=self.add_user)
        self.btn_edit = tk.Button(btn_frame, text="Tahrirlash", command=self.edit_user)
        self.btn_delete = tk.Button(btn_frame, text="O'chirish", command=self.delete_user)

        self.btn_add.pack(side="left", padx=5)
        self.btn_edit.pack(side="left", padx=5)
        self.btn_delete.pack(side="left", padx=5)
        btn_frame.pack(pady=10)

        # Joylash
        self.tree.pack(side="left", fill="both", expand=True)
        vsb.pack(side="left", fill="y")
        right_frame.pack(side="right", fill="y")

        # Ma'lumotlarni yuklash
        self.load_users()

    def load_users(self):
        """Bazadan foydalanuvchilarni yuklash"""
        for row in self.tree.get_children():
            self.tree.delete(row)

        if not self.face_db.ulanish():
            return

        cursor = self.face_db.connection.cursor()
        cursor.execute("""
            SELECT fd.id, fd.created_at,
                   COALESCE(MAX(fld.entry_time), fd.created_at) AS last_entry
            FROM face_data fd
            LEFT JOIN face_log_data fld ON fd.id = fld.id_name
            GROUP BY fd.id
            ORDER BY fd.id
        """)
        users = cursor.fetchall()
        self.face_db.ulanishni_yopish()

        for user in users:
            self.tree.insert("", "end", values=user)

    def show_user_details(self, event):
        """Tanlangan foydalanuvchi haqida ma'lumot"""
        selection = self.tree.selection()
        if not selection:
            return

        user_id = self.tree.item(selection[0], "values")[0]

        if not self.face_db.ulanish():
            return

        cursor = self.face_db.connection.cursor()
        cursor.execute("""
            SELECT img, created_at,
                   COALESCE((SELECT MAX(entry_time) FROM face_log_data WHERE id_name = fd.id), created_at)
            FROM face_data fd
            WHERE id = %s
        """, (user_id,))
        result = cursor.fetchone()
        self.face_db.ulanishni_yopish()

        if result:
            img_bytes, created_at, last_entry = result
            # Rasmni ko'rsatish
            np_img = np.frombuffer(img_bytes, np.uint8)
            img = cv2.imdecode(np_img, cv2.IMREAD_COLOR)
            img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
            pil_img = Image.fromarray(img)
            pil_img.thumbnail((200, 200))
            self.tk_img = ImageTk.PhotoImage(pil_img)
            self.image_label.config(image=self.tk_img)

            # Ma'lumotlar
            self.info_label.config(
                text=f"Foydalanuvchi ID: {user_id}\n"
                     f"Yaratilgan vaqt: {created_at}\n"
                     f"Oxirgi kirish: {last_entry}"
            )

    def add_user(self):
        messagebox.showinfo("Yangi qo'shish", "Bu yerda yangi foydalanuvchi qo'shish funksiyasi bo'ladi.")

    def edit_user(self):
        messagebox.showinfo("Tahrirlash", "Bu yerda foydalanuvchini tahrirlash funksiyasi bo'ladi.")

    def delete_user(self):
        messagebox.showinfo("O'chirish", "Bu yerda foydalanuvchini o'chirish funksiyasi bo'ladi.")


if __name__ == "__main__":
    db = FaceDB(
        dbname="face_db",
        user="postgres",
        password="123",
        host="localhost",
        port="5432"
    )
    app = UsersWindow(db)
    app.mainloop()
