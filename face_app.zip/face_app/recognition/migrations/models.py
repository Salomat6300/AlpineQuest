from django.db import models
import numpy as np
import face_recognition
from django.core.files.base import ContentFile
import base64
from datetime import datetime

class FaceData(models.Model):
    image = models.BinaryField()
    encoding = models.JSONField()
    created_at = models.DateTimeField(auto_now_add=True)

    @classmethod
    def create_from_image(cls, image_data):
        try:
            # Base64 dan rasmni decode qilish
            image_data = image_data.split(',')[1]
            image_bytes = base64.b64decode(image_data)
            
            # Yuzni tanib olish
            image = face_recognition.load_image_file(ContentFile(image_bytes))
            encodings = face_recognition.face_encodings(image)
            
            if not encodings:
                raise ValueError("Yuz aniqlanmadi")
            if len(encodings) > 1:
                raise ValueError("Ko'p yuzlar aniqlandi")
                
            encoding = encodings[0].tolist()
            
            return cls.objects.create(
                image=image_bytes,
                encoding=encoding
            )
        except Exception as e:
            raise ValueError(f"Yuzni saqlashda xato: {str(e)}")

class FaceLogData(models.Model):
    face = models.ForeignKey(FaceData, on_delete=models.CASCADE)
    entry_time = models.DateTimeField(auto_now_add=True)
    application_type = models.CharField(max_length=50)

    @classmethod
    def get_today_entries(cls, face_id):
        today = datetime.now().date()
        return cls.objects.filter(
            face_id=face_id,
            entry_time__date=today
        ).count()