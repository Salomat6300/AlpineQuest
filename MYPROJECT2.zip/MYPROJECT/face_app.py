import tkinter as tk
from tkinter import ttk, messagebox
from PIL import Image, ImageTk
import cv2
import face_recognition
import numpy as np
from datetime import datetime
from database import FaceDB
from face_orientation import FaceOrientationDetector


class YuzTanibOlovchiGUI:
    def __init__(self, face_db, video_label, status_label, user_table):
        self.face_db = face_db
        self.video_label = video_label
        self.status_label = status_label
        self.user_table = user_table

        self.video_kamera = None
        self.malum_yuz_ids = []
        self.malum_yuz_kodlari = []
        self.orient_detector = FaceOrientationDetector()
        self.oxirgi_log_vaqtlari = {}
        self.running = False

        self.face_recognition_gpu_enabled = False
        try:
            import dlib
            if dlib.DLIB_USE_CUDA:
                self.face_recognition_gpu_enabled = True
                print("GPU acceleration is enabled for face recognition")
            else:
                print("Warning: GPU acceleration not available for face recognition")
        except:
            print("Warning: Could not check GPU acceleration status")

    def ishga_tushirish(self):
        self.malum_yuz_ids, self.malum_yuz_kodlari = self.face_db.barcha_yuzlarni_olish()
        self.video_kamera = cv2.VideoCapture(0)
        if not self.video_kamera.isOpened():
            return False
        if self.malum_yuz_kodlari:
            self.malum_yuz_kodlari = np.array(self.malum_yuz_kodlari)
        self.running = True
        self.status_label.config(text="Holat: Tizim ishga tushdi")
        self.update_frame()
        return True

    def get_main_face(self, face_locations, frame_shape):
        if not face_locations:
            return None
        height, width = frame_shape[:2]
        center_x, center_y = width // 2, height // 2
        min_distance = float('inf')
        main_face = None
        for (top, right, bottom, left) in face_locations:
            face_center_x = (left + right) // 2
            face_center_y = (top + bottom) // 2
            distance = np.sqrt((face_center_x - center_x)**2 + (face_center_y - center_y)**2)
            if distance < min_distance:
                min_distance = distance
                main_face = (top, right, bottom, left)
        return main_face

    def update_frame(self):
        if not self.running:
            return
        ret, kadr = self.video_kamera.read()
        if not ret:
            self.tozalash()
            return
        kadr = cv2.flip(kadr, 1)
        small_frame = cv2.resize(kadr, (0, 0), fx=0.5, fy=0.5)
        rgb_kadr = cv2.cvtColor(small_frame, cv2.COLOR_BGR2RGB)

        try:
            yuz_joylari = face_recognition.face_locations(
                rgb_kadr,
                model="cnn" if self.face_recognition_gpu_enabled else "hog"
            )
            yuz_joylari = [(t*2, r*2, b*2, l*2) for (t, r, b, l) in yuz_joylari]
            main_face = self.get_main_face(yuz_joylari, kadr.shape)
            ism = "Yuz topilmadi"
            if main_face:
                yuz_kodlari = face_recognition.face_encodings(
                    rgb_kadr,
                    known_face_locations=[(main_face[0]//2, main_face[1]//2, main_face[2]//2, main_face[3]//2)],
                    num_jitters=1
                )
                if yuz_kodlari:
                    yuz_kodi = yuz_kodlari[0]
                    yuqori, ong, past, chap = main_face
                    sub_frame = kadr[yuqori:past, chap:ong]
                    orientation = self.orient_detector.detect(sub_frame)
                    if not orientation:
                        ism = "Yuz holati notog‘ri"
                    else:
                        if len(self.malum_yuz_kodlari) > 0:
                            masofalar = face_recognition.face_distance(self.malum_yuz_kodlari, yuz_kodi)
                            eng_yaqin = np.argmin(masofalar)
                            if masofalar[eng_yaqin] < 0.5:
                                yuz_id = self.malum_yuz_ids[eng_yaqin]
                                ism = f"ID-{yuz_id}"
                                log_kerak = yuz_id not in self.oxirgi_log_vaqtlari or \
                                            (datetime.now() - self.oxirgi_log_vaqtlari[yuz_id]).total_seconds() >= 30
                                if log_kerak:
                                    self.face_db.kirishni_loglash(yuz_id)
                                    self.oxirgi_log_vaqtlari[yuz_id] = datetime.now()
                            else:
                                ism = "Nomalum shaxs!"
                                yuz_id = None
                        else:
                            ism = "Nomalum shaxs!"
                            yuz_id = None
                        if ism == "Nomalum shaxs!":
                            yuz_rasmi = kadr[yuqori:past, chap:ong]
                            yuz_id = self.face_db.yuz_qoshish(yuz_rasmi, yuz_kodi)
                            if yuz_id:
                                ism = f"ID-{yuz_id}"
                                self.malum_yuz_ids.append(yuz_id)
                                self.malum_yuz_kodlari = np.vstack([self.malum_yuz_kodlari, yuz_kodi]) \
                                    if len(self.malum_yuz_kodlari) > 0 else np.array([yuz_kodi])
                                self.oxirgi_log_vaqtlari[yuz_id] = datetime.now()
                                self.load_users()
                    cv2.rectangle(kadr, (chap, yuqori), (ong, past), (0, 255, 0), 2)
                    cv2.putText(kadr, ism, (chap + 6, past - 6), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 1)
        except Exception as e:
            print("Xatolik:", e)

        img = cv2.cvtColor(kadr, cv2.COLOR_BGR2RGB)
        img_pil = Image.fromarray(img)
        img_tk = ImageTk.PhotoImage(image=img_pil)
        self.video_label.imgtk = img_tk
        self.video_label.config(image=img_tk)

        self.video_label.after(20, self.update_frame)

    def load_users(self):
        self.user_table.delete(*self.user_table.get_children())
        if not self.face_db.ulanish():
            return
        cursor = self.face_db.connection.cursor()
        cursor.execute("SELECT id, created_at FROM face_data ORDER BY id ASC")
        for row in cursor.fetchall():
            self.user_table.insert("", tk.END, values=row)
        self.face_db.ulanishni_yopish()

    def tozalash(self):
        self.running = False
        if self.video_kamera:
            self.video_kamera.release()
        self.status_label.config(text="Holat: Tizim to‘xtadi")


class FaceApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Face Recognition System")
        self.root.geometry("1000x600")
        self.face_db = FaceDB("face_db", "postgres", "123", "localhost", "5432")

        # Video panel
        self.video_label = tk.Label(root, bg="black")
        self.video_label.place(x=10, y=10, width=640, height=480)

        # Foydalanuvchilar paneli
        user_frame = ttk.LabelFrame(root, text="Foydalanuvchilar", padding=10)
        user_frame.place(x=660, y=10, width=330, height=480)
        columns = ("id", "created_at")
        self.user_table = ttk.Treeview(user_frame, columns=columns, show="headings", height=20)
        self.user_table.heading("id", text="ID")
        self.user_table.heading("created_at", text="Sana/Vaqt")
        self.user_table.column("id", width=50, anchor="center")
        self.user_table.column("created_at", width=200, anchor="center")
        self.user_table.pack(fill=tk.BOTH, expand=True)

        # Holat paneli
        self.status_label = tk.Label(root, text="Holat: Kutish...", bg="#ddd", anchor="w", font=("Arial", 10))
        self.status_label.place(x=10, y=560, width=980, height=30)

        # Tugmalar
        tk.Button(root, text="▶ Yoqish", bg="green", fg="white", font=("Arial", 12),
                  command=self.start).place(x=200, y=510, width=120, height=40)
        tk.Button(root, text="⏹ To‘xtatish", bg="red", fg="white", font=("Arial", 12),
                  command=self.stop).place(x=350, y=510, width=120, height=40)
        tk.Button(root, text="❌ Chiqish", bg="gray", fg="white", font=("Arial", 12),
                  command=self.exit).place(x=500, y=510, width=120, height=40)

        # Yuz tanish obyekt
        self.recognizer = YuzTanibOlovchiGUI(self.face_db, self.video_label, self.status_label, self.user_table)
        self.recognizer.load_users()

    def start(self):
        if not self.recognizer.ishga_tushirish():
            messagebox.showerror("Xatolik", "Kamerani ochib bo‘lmadi!")

    def stop(self):
        self.recognizer.tozalash()

    def exit(self):
        self.stop()
        self.root.destroy()


if __name__ == "__main__":
    root = tk.Tk()
    app = FaceApp(root)
    root.mainloop()
