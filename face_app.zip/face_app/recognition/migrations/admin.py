from django.contrib import admin
from .models import FaceData, FaceLogData

@admin.register(FaceData)
class FaceDataAdmin(admin.ModelAdmin):
    list_display = ('id', 'created_at')
    readonly_fields = ('created_at',)

@admin.register(FaceLogData)
class FaceLogDataAdmin(admin.ModelAdmin):
    list_display = ('face', 'entry_time', 'application_type')
    list_filter = ('application_type', 'entry_time')
    readonly_fields = ('entry_time',)